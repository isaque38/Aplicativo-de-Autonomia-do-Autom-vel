/*
*@author: Isaque de Lima Vieira
*RA: 1110482123042
*/
package com.example.autonomiadeautomovel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private var etConsumoMedio: EditText? = null
    private var etLitros: EditText? = null
    private var tvResultado: TextView? = null
    private var btnCalcular: Button? = null

    @Override
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etConsumoMedio = findViewById(R.id.etConsumoMedio)
        etLitros = findViewById(R.id.etLitros)
        tvResultado = findViewById(R.id.tvResultado)
        btnCalcular = findViewById(R.id.btnCalcular)

        btnCalcular.setOnClickListener(object : OnClickListener() {
            @Override
            fun onClick(v: View?) {
                calcularAutonomia()
            }
        })
    }

    private fun calcularAutonomia() {
        val consumoMedio: Double = Double.parseDouble(etConsumoMedio.getText().toString())
        val litros: Double = Double.parseDouble(etLitros.getText().toString())


        // Calcular a autonomia em km e converter para metros
        val autonomiaMetros = (consumoMedio * litros) * 1000
        tvResultado.setText("Autonomia: $autonomiaMetros metros")
    }
}